import { NextResponse } from "next/server";
import {
  getCustomerByEmail,
  getPolicies,
  getPayments,
  getClaims,
  getDocuments,
} from "@/lib/excel";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const email = (searchParams.get("email") || "").trim();
  if (!email) {
    return NextResponse.json({ ok: false, error: "Email is required" }, { status: 400 });
  }

  const customer = getCustomerByEmail(email);
  if (!customer) {
    return NextResponse.json(
      { ok: false, error: "No account found for that email. Try the demo account instead." },
      { status: 404 }
    );
  }

  const policies = getPolicies().filter((p) => p.customerId === customer.customerId);
  const policyIds = new Set(policies.map((p) => p.policyId));
  const payments = getPayments()
    .filter((p) => policyIds.has(p.policyId))
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  const claims = getClaims()
    .filter((c) => policyIds.has(c.policyId))
    .sort((a, b) => (b.submittedDate || "").localeCompare(a.submittedDate || ""));
  const documents = getDocuments().filter((d) => policyIds.has(d.policyId));

  return NextResponse.json({ ok: true, customer, policies, payments, claims, documents });
}
